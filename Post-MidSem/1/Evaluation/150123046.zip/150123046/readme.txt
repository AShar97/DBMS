## Place the file "load.py" & the directory "webapp" as such that they have sister directory "workshop_dataset1" containg all the datewise json files.


# Run the following commands:
$ python2 load.py
$ python2 webapp/app.py

# Open the IP address listed on running output of the last command.

# You are successsfully running the webapp for implementation of the Assignment queries.


#* Created by Ayush Sharma. Signed as AShar. */