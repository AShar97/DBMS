## Place the file "load.py" & the directory "webapp" as such that they have sister file "dataset.json" containing the provided json file.

## Run the following commands:
$ python load.py
$ python webapp/app.py

# Open the IP address listed on running output of the last command.

# You are successsfully running the webapp for implementation of the Assignment queries.

#/* Optionally, open the IP address of your Neo4j server (default: "http://localhost:7474/"). */#


#* Created by Ayush Sharma. Signed as AShar. *#